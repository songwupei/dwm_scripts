#!/bin/zsh
## source by ~/.zshrc
## 11.pandoc convert
mdstodocxs(){
		for name ($(fd -e ${${1:t}:e} ${${1:t}:r} ${1:h}) ){
			mdtodocx $name
	}
}
mdtodocx() {
		# base the reference-doc 
		# pandoc md to docx
	fname=$1
	ofile=${fname:h}/${${fname:t}:r}_md.docx
	pandoc -s ${fname} -o $ofile --reference-doc=/home/song/NutstoreFiles/0-Notes/1-MyNormals/normal.dotx
	unset fname
	echo "convert $1 to ${${1:t}:r}.dotx"
}

docxstomds(){
		for name ($(fd -e ${${1:t}:e} ${${1:t}:r} ${1:h}) ){
			   docxtomd $name
	}
}

docxtomd() {
		# base the reference-doc 
		# pandoc md to docx
	# fname=$(fd $1 -e docx) #if has extend  -e docx)
	fname=$1
	echo "convert docx to markdown"
	pandoc  -s ${fname} -f docx -t markdown -o "${fname:r}.md" 
	unset fname
	echo "convert $1 to ${1:r}.md"
}

formatmds() {
		for name ($(fd -e ${${1:t}:e} ${${1:t}:r} ${1:h}) ){
			   formatmd $name $2
}
}

formatmd() {
	dir_path=${1:h}
	hanznum=一二三四五六七八九十
	(($+2)) && {
	case $2 {
		(basic)
		#sed -e 's/\([一二三四五六七八九十]、\)/## \1/' -e '1s/^/# /' -e 's/\(（\([一二三四五六七八九]\)）\)/### \1/' -e 's/\(^附件1\)/<br>\n\n<br\/>\n\n\1/' $1 > "${1:r}_format.${1:e}"
		sed -e 's/\([一二三四五六七八九十]、\)/## \1/' -e '1s/^/# /' -e '2s/^/\n\n<br>\n\n/' -e 's/\(（\([一二三四五六七八九]\)）\)/### \1/' -e 's/\(^附件1\)/\n\n<br>\n\n\1/' -e 's/你集团下属单位/你单位所属/g' $1 > "${1:r}_format.${1:e}"
		;;
	(inline)
		# replacehznum 解决sed 的贪婪模式， [^str]可以截断
		tmpmd=${1:r}_tmp.${1:e}
		replacehznum $1 > ${tmpmd}
	        sed -e 's/\([一二三四五六七八九十]、\)/## \1/' -e '1s/^/# /' -e 's/\(（\([一二三四五六七八九十]\)）\)/### \1/' -e 's/\(^附件1\)/\n\n<br>\n\n\1/' ${tmpmd} > "${1:r}_format.${1:e}"
		rm ${tmpmd}
		;;
		(yuebao)
		tmpmd=${1:r}_tmp.${1:e}
		replacehznum $1 > ${tmpmd}
		## basic add remove 1 line bold
		sed -i '/./,$!d' ${tmpmd}
		sed -e 's/^\*\*\([0-9]\+\..*\)\*\*$/\1/' -e 's/\*\*\([0-9]\+\..*\)\*\*/\1/g' -e 's/\*\*\([^ ].*[^ ]\)\*\*/\1/g' -e 's/\([一二三四五六七八九十]、\)/## \1/' -e '1s/^/# /'  -e 's/\(（\([一二三四五六七八九]\)）\)/### \1/' -e 's/\(^附件1\)/\n\n<br>\n\n\1/'   ${tmpmd} > "${1:r}.${1:e}"

  	rm ${tmpmd}
		;;
		(zhidu)
		sed -e 's/\(第[一二三四五六七八九十]\{1,3\}章\)/## \\indent \1/' -e '1s/^/# /' -e '2s/^/\n\n<br>\n\n/' -e 's/\(第[一二三四五六七八九十]\{1,3\}条\)/　　\*\*\1\*\*/'  $1 > "${1:r}_format.${1:e}"
		;;
####	(skBold)
####		# 暂时无法解决sed 的贪婪模式，需要使用202去截断
####		# 网上说 perl -pe [^str]可以截断， TODO
####		sed -e 's/\([一二三四五六]、\)/## \1/' -e '1s/^/# /' -e 's/\(（[一二三四五六七八九十]）.*。\)\(202\)/**\1**\2/' $1  -e 's/\(^附件1\)/<br\/>\n\r\n\r\1/'> "${1:r}_format.${1:e}"
####		;;
	(*)
	echo 	err
		;;
	}
}
	echo 'format $1 ;then convert to docx'
	echo "format $1 to ${1:r}_f<D-s>rmat.${1:e}"
}
replacehznum() {
    # 删除临时文件夹
    formatmdTemp="/tmp/formatmdTemp"
    formatmdCmd="$formatmdTemp/formatmdCmd"

    [[ -e $formatmdTemp ]] && rm -rf $formatmdTemp
    mkdir -p $formatmdTemp

    # 查找包含中文数字括号的行号
    nl -ba "$1" | grep '（[一二三四五六七八九]）' | cut -f 1 | tr -d '\n' > "$formatmdTemp/linesnumber"

    # 读取行号到数组
    nls=($(cat "$formatmdTemp/linesnumber"))
    #echo "Line numbers: ${nls[@]}"

    # 定义中文数字
    hanznum=("一" "二" "三" "四" "五" "六" "七" "八" "九" "十")

    # 生成 sed 命令
    printf "sed " > "$formatmdCmd"
    for lnum in "${nls[@]}"; do
        # 计算中文数字索引
        hzindex=$(( ${nls[(ie)$lnum]} ))
        if [[ $hzindex -ge 0 && $hzindex -lt ${#hanznum[@]} ]]; then
            # 生成 sed 替换命令
            printf " -e '%s s/（[一二三四五六七八九]）/（%s）/' " "$lnum" "${hanznum[$hzindex]}" >> "$formatmdCmd"
        else
            #echo "Error: Invalid index for hanznum: $hzindex"
        fi
    done
    printf "%s" "$1" >> "$formatmdCmd"

    # 打印生成的 sed 命令（调试用）
    # echo "Generated sed command:"
    #cat "$formatmdCmd"

    # 执行 sed 命令
    zsh "$formatmdCmd"
}

##replacehznum() {
##	# 删除tmp文件夹
##	formatmdTemp="/tmp/formatmdTemp"
##	formatmdCmd="$formatmdTemp/formatmdCmd"
##	[[ -e $formatmdTemp ]] && rm -rf $formatmdTemp 
##        mkdir $formatmdTemp
##	# nl -ba ==include blank lines
##	nl -ba $1 | grep （[一二三四五六七八九]）| cut -f 1 | tr -d '\n' > $formatmdTemp/linesnumber
##	# nls=$(nl $1 | grep （[一二三四]）| cut -f 1 | tr -d '\n')
##nls=($(cat $formatmdTemp/linesnumber))
##txt=$(cat $1)
##hanznum="一二三四五六七八九十"
##printf "sed " > $formatmdCmd
##for lnum ($nls) { 
##hzindex=${nls[(ie)$lnum]}
#### case1:1-only format Heading3 （一）xx。regex not greed :use [^str] 
##printf " -e '%s s/（[一二三四五六七八九]）/（%s）/' %s" ${lnum} ${hanznum[$hzindex]} 1  >> $formatmdCmd
#### case1:2-replace (一) (三) to(一) (二) 
####printf " -e '%s s/（[一二三四五六七八九]）\([^。]*。\)/（%s）\\%s/' %s" ${lnum} ${hanznum[$hzindex]} 1  >> $formatmdCmd
#### case2:case1 + second format NormalCharacter<span>***</span>
#### printf " -e '%s s/（[一二三四五六七八九]）\([^。]*。\)\(.*。\)/（%s）\\%s<span custom-style="NormalCharacter">\\%s<\/span>/' %s" ${lnum} ${hanznum[$hzindex]} 1 2  >> $formatmdCmd
##}
##printf "%s" $1 >> $formatmdCmd
##zsh $formatmdCmd 
##
##}
##
mdtopdf() {
	echo "convert md to pdf"
fname=$1
pdf_template=/home/song/NutstoreFiles/0-Notes/1-MyNormals/eisvogel.tex
pdf_engine=~/bin/xelatex

# fc-list :lang=zh 查看字体
[[ -z $2 ]] && CJKmainfont="等距更纱黑体 SC"
[[ -n $2 ]] && CJKmainfont=$2
pandoc -s $1 -o ${fname:r}.pdf --from markdown --template $pdf_template --listings --pdf-engine $pdf_engine  -V CJKmainfont=$CJKmainfont
	unset fname
	unset pdf_engine
	unset pdf_template
	echo "convert $1 to ${1:r}.pdf"
}
